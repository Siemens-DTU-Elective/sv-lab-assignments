module apb_slave (
  input  logic        pclk,
  input  logic        presetn,
  input  logic        psel,
  input  logic        penable,
  input  logic        pwrite,
  input  logic [31:0] paddr,
  input  logic [31:0] pwdata,
  output logic [31:0] prdata,
  output logic        pready,
  output logic        pslverr
);

  logic [31:0] mem [0:63];

  assign pready  = 1'b1;
  assign pslverr = 1'b0;
  assign prdata  = mem[paddr[7:2]];

  always_ff @(posedge pclk or negedge presetn) begin
    if (!presetn) begin
      for (int i = 0; i < 64; i++)
        mem[i] <= '0;
    end
    else if (psel && penable && pready && pwrite) begin
      mem[paddr[7:2]] <= pwdata;
    end
  end

endmodule
