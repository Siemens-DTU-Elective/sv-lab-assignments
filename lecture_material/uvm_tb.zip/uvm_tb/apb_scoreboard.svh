class apb_scoreboard extends uvm_scoreboard;

  `uvm_component_utils(apb_scoreboard)

  uvm_analysis_imp #(apb_txn, apb_scoreboard) analysis_export;

  bit [31:0] expected_mem [bit [5:0]];

  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
  endfunction

  function void write(apb_txn tr);

    if (tr.write) begin
      expected_mem[tr.addr[7:2]] = tr.data;

      `uvm_info("APB_SCB",
        $sformatf("WRITE: addr=%08h data=%08h",
                  tr.addr, tr.data), UVM_MEDIUM)
    end
    else begin
      if (!expected_mem.exists(tr.addr[7:2])) begin
        `uvm_error("APB_SCB",
          $sformatf("Read from unwritten address %08h", tr.addr))
      end
      else if (expected_mem[tr.addr[7:2]] !== tr.data) begin
        `uvm_error("APB_SCB",
          $sformatf("Mismatch addr=%08h expected=%08h actual=%08h",
                    tr.addr, expected_mem[tr.addr[7:2]], tr.data))
      end
      else begin
        `uvm_info("APB_SCB",
          $sformatf("PASS: addr=%08h data=%08h",
                    tr.addr, tr.data), UVM_MEDIUM)
      end
    end

  endfunction

endclass
