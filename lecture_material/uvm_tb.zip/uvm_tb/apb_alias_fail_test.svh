// Alias regression test; the legacy class name is retained for existing runs.
class apb_alias_fail_test extends apb_test;

  `uvm_component_utils(apb_alias_fail_test)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    apb_sequence::type_id::set_type_override(apb_alias_sequence::get_type());
    super.build_phase(phase);
  endfunction

endclass
