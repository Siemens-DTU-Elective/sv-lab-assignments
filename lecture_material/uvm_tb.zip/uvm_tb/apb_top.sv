module top;

  import uvm_pkg::*;
  import apb_pkg::*;

  bit pclk = 0;

  always #5 pclk = ~pclk;

  apb_if apb(pclk);

  apb_slave dut (
    .pclk    (pclk),
    .presetn (apb.presetn),
    .psel    (apb.psel),
    .penable (apb.penable),
    .pwrite  (apb.pwrite),
    .paddr   (apb.paddr),
    .pwdata  (apb.pwdata),
    .prdata  (apb.prdata),
    .pready  (apb.pready),
    .pslverr (apb.pslverr)
  );

  initial begin
    apb.presetn = 0;

    uvm_config_db#(virtual apb_if)::set(null, "uvm_test_top.env.agent.*", "vif", apb);
    uvm_config_db#(int)::set( null, "uvm_test_top.env.agent.*", "addr_test", 100 );

    // run_test() must be called at time 0; reset is released in its own process
    run_test("apb_test");
  end

  initial begin
    repeat (3) @(negedge pclk);
    apb.presetn = 1;
  end

`ifdef APB_DUMP_VCD
  initial begin
    $dumpfile("apb_top.vcd");
    $dumpvars(0, top);
    $dumpon;
  end
`endif

endmodule
