class apb_sequence extends uvm_sequence #(apb_txn);

  `uvm_object_utils(apb_sequence)

  function new(string name = "apb_sequence");
    super.new(name);
  endfunction

  int unsigned num_txns = 10;

  task body();
    apb_txn    tr;
    bit [31:0] addrs[];

    // Unique word-aligned addresses within the slave's 64-word memory
    addrs = new[num_txns];
    if (!std::randomize(addrs) with {
          unique {addrs};
          foreach (addrs[i]) { addrs[i] < 32'h100; addrs[i][1:0] == 2'b00; }
        })
      `uvm_fatal("APB_SEQ", "Address randomization failed")

    // Write phase
    foreach (addrs[i]) begin
      tr = apb_txn::type_id::create($sformatf("write_tr_%0d", i));
      start_item(tr);
      if (!tr.randomize() with { write == 1; addr == addrs[i]; })
        `uvm_fatal("APB_SEQ", "Write txn randomization failed")
      finish_item(tr);
    end

    // Read-back phase
    foreach (addrs[i]) begin
      tr = apb_txn::type_id::create($sformatf("read_tr_%0d", i));
      start_item(tr);
      if (!tr.randomize() with { write == 0; addr == addrs[i]; data == 0; })
        `uvm_fatal("APB_SEQ", "Read txn randomization failed")
      finish_item(tr);
    end

  endtask

endclass
