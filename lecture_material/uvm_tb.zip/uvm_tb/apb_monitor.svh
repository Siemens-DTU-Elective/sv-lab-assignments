class apb_monitor extends uvm_monitor;

  `uvm_component_utils(apb_monitor)

  virtual apb_if vif;
  uvm_analysis_port #(apb_txn) ap;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(virtual apb_if)::get(
          this, "", "vif", vif))
      `uvm_fatal("APB_MON", "Virtual interface not configured")
  endfunction

  task run_phase(uvm_phase phase);
    apb_txn tr;

    forever begin
      @(posedge vif.pclk);

      if (vif.presetn && vif.psel &&
          vif.penable && vif.pready) begin

        tr = apb_txn::type_id::create("tr");

        tr.write = vif.pwrite;
        tr.addr  = vif.paddr;
        tr.data  = vif.pwrite ? vif.pwdata : vif.prdata;

        ap.write(tr);
      end
    end
  endtask

endclass
