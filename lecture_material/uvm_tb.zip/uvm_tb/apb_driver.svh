class apb_driver extends uvm_driver #(apb_txn);

  `uvm_component_utils(apb_driver)

  virtual apb_if vif;
  int addr_driver;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(virtual apb_if)::get(
          this, "", "vif", vif))
      `uvm_fatal("APB_DRV", "Virtual interface not configured")
    
      
      if (!uvm_config_db#(int)::get(this, "", "addr_test", addr_driver))
      `uvm_fatal("APB_DRV", "addr_test configuration not found")
    else
      `uvm_info("DRIVER_CLASS",
        $sformatf("The value of addr_test is =%0d", addr_driver),
        UVM_NONE)
  endfunction

  task run_phase(uvm_phase phase);
    apb_txn tr;

    // Initialize APB signals
    vif.psel    = 0;
    vif.penable = 0;
    vif.pwrite  = 0;
    vif.paddr   = 0;
    vif.pwdata  = 0;

    wait (vif.presetn === 1'b1);

    forever begin
      seq_item_port.get_next_item(tr);

      // Setup phase
      @(negedge vif.pclk);
      vif.psel    = 1;
      vif.penable = 0;
      vif.pwrite  = tr.write;
      vif.paddr   = tr.addr;
      vif.pwdata  = tr.data;

      // Access phase
      @(negedge vif.pclk);
      vif.penable = 1;

      // Hold control signals stable during wait states
      do begin
        @(posedge vif.pclk);
      end while (vif.pready !== 1'b1);

      if (!tr.write)
        tr.data = vif.prdata;

      `uvm_info("APB_DRV",
        $sformatf("%s addr=%08h data=%08h",
          tr.write ? "WRITE" : "READ",
          tr.addr, tr.data),
        UVM_MEDIUM)

      // End transfer
      @(negedge vif.pclk);
      vif.psel    = 0;
      vif.penable = 0;
      vif.pwrite  = 0;

      seq_item_port.item_done();
    end
  endtask

endclass
