// Writes two addresses that alias in apb_slave (only paddr[7:2] is decoded),
// then reads both back. The second write overwrites the first location, so
// the scoreboard reports a data mismatch on the first read.
class apb_alias_sequence extends apb_sequence;

  `uvm_object_utils(apb_alias_sequence)

  function new(string name = "apb_alias_sequence");
    super.new(name);
  endfunction

  task body();
    bit [31:0] addrs[2] = '{32'h0000_0010, 32'h0000_0110};
    bit [31:0] datas[2] = '{32'hAAAA_0010, 32'hBBBB_0110};
    apb_txn    tr;

    foreach (addrs[i]) begin
      tr = apb_txn::type_id::create($sformatf("write_tr_%0d", i));
      start_item(tr);
      tr.write = 1;
      tr.addr  = addrs[i];
      tr.data  = datas[i];
      finish_item(tr);
    end

    foreach (addrs[i]) begin
      tr = apb_txn::type_id::create($sformatf("read_tr_%0d", i));
      start_item(tr);
      tr.write = 0;
      tr.addr  = addrs[i];
      tr.data  = 0;
      finish_item(tr);
    end
  endtask

endclass
