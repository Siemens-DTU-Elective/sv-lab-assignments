// testbench.sv -- the EDA Playground 'testbench' tab. Your files are the tabs student_pkg.sv and tb_top.sv.
// To add a file of your own: create a tab for it with the + button, then `include it here BEFORE tb_top.sv
// (or inside student_pkg.sv, between the package header and endpackage).
`include "student_pkg.sv"
`include "tb_top.sv"
