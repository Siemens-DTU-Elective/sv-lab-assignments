//======================================================================
// tb_top.sv -- YOUR top module.  Fill in the numbered steps (details: handout, sections 3.1 to 3.3).
//======================================================================
`timescale 1ns/1ps
`include "uvm_macros.svh"
module tb_top;
  import uvm_pkg::*;
  import i2c_contest_pkg::*;
  import student_pkg::*;

  // STEP 1  Clock: declare a clock signal and generate it. Any period works.
  // STEP 2  Bus: instantiate the interface i2c_if and connect your clock to it.
  //         (Until this step is done the simulator stops with "Virtual interface resolution cannot find a matching instance".)
  // STEP 3  Device: instantiate contest_dut and connect every pin as listed in the handout, section 3.1
  //         (the same pins, with a comment each, are above the module header of contest_dut).
  // STEP 4  Reset: drive the bus reset low at the start for at least 5 clock cycles, then release it.
  //         Initialise the master pull-downs to 0 (handout, section 3.2).
  // STEP 5  Give the bus to the driver: put the virtual interface into uvm_config_db under the key
  //         the driver reads (handout, section 3.3).
  // STEP 6  Start UVM: call run_test() without an argument. The marking run selects your test by name.
endmodule
