//======================================================================
// student_pkg.sv -- YOUR testbench classes.  Fill in every TODO.
// The class names below are required (see the Student Guide, section 4).  You may add classes and files.
// Details of the provided driver and item: handout, sections 3.3 and 3.4.
//======================================================================
`include "uvm_macros.svh"
package student_pkg;
  import uvm_pkg::*;
  import i2c_contest_pkg::*;

  //--------------------------------------------------------------------
  // BLOCK 1 -- SEQUENCE API: helper tasks that build an item and send it.
  //    Make them reusable: arguments instead of copy-and-paste, clear names, one short comment each.
  //--------------------------------------------------------------------
  class my_api_seq extends uvm_sequence #(i2c_item);
    `uvm_object_utils(my_api_seq)
    function new(string name = "my_api_seq");
      super.new(name);
    endfunction

    // TODO: a task that sends one item (start_item, finish_item).
    // TODO: helper tasks for the kinds of transfer you want to make. The item fields are in the handout, section 3.4.
  endclass

  //--------------------------------------------------------------------
  // BLOCK 2 -- SEQUENCE: the stimulus of your test, built from your helpers.
  //--------------------------------------------------------------------
  class student_seq extends my_api_seq;
    `uvm_object_utils(student_seq)
    function new(string name = "student_seq");
      super.new(name);
    endfunction

    task body();
      // TODO: your stimulus.
    endtask
  endclass

  //--------------------------------------------------------------------
  // BLOCK 3 -- SCOREBOARD: a model of the device, and the comparison with what the driver observed.
  //    write() is called once for every finished item.
  //    TODO: from the datasheet and UM10204 work out what the device should do for the item, compare it with
  //    t.acks and t.read_data, and report every mismatch as a UVM error (uvm_error).
  //    Keep the state your model needs. If t.dut_reset is set, the device lost its state after this item.
  //--------------------------------------------------------------------
  class student_scoreboard extends uvm_subscriber #(i2c_item);
    `uvm_component_utils(student_scoreboard)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction

    function void write(i2c_item t);
      // TODO
    endfunction
  endclass

  //--------------------------------------------------------------------
  // BLOCK 4 -- COVERAGE: decide from the standard and the datasheet what matters, write covergroup(s) for it,
  //    and sample them in write(), from the items the driver publishes (nowhere else).
  //    In report_phase, report EVERY coverpoint and EVERY cross, one call each, with the provided helper:
  //        int covered, total;  void'(my_group.my_point.get_inst_coverage(covered, total));  report_coverage("my_point", covered, total);
  //--------------------------------------------------------------------
  class student_cov extends uvm_subscriber #(i2c_item);
    `uvm_component_utils(student_cov)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction

    function void write(i2c_item t);
      // TODO
    endfunction

    function void report_phase(uvm_phase phase);
      // TODO: report your coverage (see the instructions above)
    endfunction
  endclass

  //--------------------------------------------------------------------
  // BLOCK 5 -- ENVIRONMENT: create the provided driver (i2c_driver), a sequencer (uvm_sequencer #(i2c_item)),
  //    your scoreboard and your coverage, and connect them.
  //--------------------------------------------------------------------
  class student_env extends uvm_env;
    `uvm_component_utils(student_env)
    // TODO: declare handles for the components.
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
      // TODO: create the components with the factory.
    endfunction

    function void connect_phase(uvm_phase phase);
      // TODO: connect the sequencer to the driver, and the driver's result_port to your scoreboard and your coverage.
    endfunction
  endclass

  //--------------------------------------------------------------------
  // BLOCK 6 -- TEST: build your environment and run your sequence. The marking run starts this class by name.
  //--------------------------------------------------------------------
  class student_test extends uvm_test;
    `uvm_component_utils(student_test)
    // TODO: a handle for your environment.
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
      // TODO: create the environment.
    endfunction

    task run_phase(uvm_phase phase);
      // TODO: raise an objection, start your sequence on the sequencer of your environment, drop the objection when it is done.
    endtask
  endclass
endpackage
